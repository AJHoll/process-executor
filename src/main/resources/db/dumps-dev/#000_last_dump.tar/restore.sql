--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.11
-- Dumped by pg_dump version 12.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE prc_exec;
--
-- Name: prc_exec; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE prc_exec WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Russian_Russia.1251@icu' LC_CTYPE = 'Russian_Russia.1251';


\connect prc_exec

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: act_ge_bytearray; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ge_bytearray (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    name_ character varying(255),
    deployment_id_ character varying(64),
    bytes_ bytea,
    generated_ boolean,
    tenant_id_ character varying(64),
    type_ integer,
    create_time_ timestamp without time zone,
    root_proc_inst_id_ character varying(64),
    removal_time_ timestamp without time zone
);


--
-- Name: act_ge_property; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ge_property (
    name_ character varying(64) NOT NULL,
    value_ character varying(300),
    rev_ integer
);


--
-- Name: act_ge_schema_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ge_schema_log (
    id_ character varying(64) NOT NULL,
    timestamp_ timestamp without time zone,
    version_ character varying(255)
);


--
-- Name: act_hi_actinst; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_actinst (
    id_ character varying(64) NOT NULL,
    parent_act_inst_id_ character varying(64),
    proc_def_key_ character varying(255),
    proc_def_id_ character varying(64) NOT NULL,
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64) NOT NULL,
    execution_id_ character varying(64) NOT NULL,
    act_id_ character varying(255) NOT NULL,
    task_id_ character varying(64),
    call_proc_inst_id_ character varying(64),
    call_case_inst_id_ character varying(64),
    act_name_ character varying(255),
    act_type_ character varying(255) NOT NULL,
    assignee_ character varying(255),
    start_time_ timestamp without time zone NOT NULL,
    end_time_ timestamp without time zone,
    duration_ bigint,
    act_inst_state_ integer,
    sequence_counter_ bigint,
    tenant_id_ character varying(64),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_attachment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_attachment (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    user_id_ character varying(255),
    name_ character varying(255),
    description_ character varying(4000),
    type_ character varying(255),
    task_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    url_ character varying(4000),
    content_id_ character varying(64),
    tenant_id_ character varying(64),
    create_time_ timestamp without time zone,
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_batch; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_batch (
    id_ character varying(64) NOT NULL,
    type_ character varying(255),
    total_jobs_ integer,
    jobs_per_seed_ integer,
    invocations_per_job_ integer,
    seed_job_def_id_ character varying(64),
    monitor_job_def_id_ character varying(64),
    batch_job_def_id_ character varying(64),
    tenant_id_ character varying(64),
    create_user_id_ character varying(255),
    start_time_ timestamp without time zone NOT NULL,
    end_time_ timestamp without time zone,
    removal_time_ timestamp without time zone,
    exec_start_time_ timestamp without time zone
);


--
-- Name: act_hi_caseactinst; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_caseactinst (
    id_ character varying(64) NOT NULL,
    parent_act_inst_id_ character varying(64),
    case_def_id_ character varying(64) NOT NULL,
    case_inst_id_ character varying(64) NOT NULL,
    case_act_id_ character varying(255) NOT NULL,
    task_id_ character varying(64),
    call_proc_inst_id_ character varying(64),
    call_case_inst_id_ character varying(64),
    case_act_name_ character varying(255),
    case_act_type_ character varying(255),
    create_time_ timestamp without time zone NOT NULL,
    end_time_ timestamp without time zone,
    duration_ bigint,
    state_ integer,
    required_ boolean,
    tenant_id_ character varying(64)
);


--
-- Name: act_hi_caseinst; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_caseinst (
    id_ character varying(64) NOT NULL,
    case_inst_id_ character varying(64) NOT NULL,
    business_key_ character varying(255),
    case_def_id_ character varying(64) NOT NULL,
    create_time_ timestamp without time zone NOT NULL,
    close_time_ timestamp without time zone,
    duration_ bigint,
    state_ integer,
    create_user_id_ character varying(255),
    super_case_instance_id_ character varying(64),
    super_process_instance_id_ character varying(64),
    tenant_id_ character varying(64)
);


--
-- Name: act_hi_comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_comment (
    id_ character varying(64) NOT NULL,
    type_ character varying(255),
    time_ timestamp without time zone NOT NULL,
    user_id_ character varying(255),
    task_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    action_ character varying(255),
    message_ character varying(4000),
    full_msg_ bytea,
    tenant_id_ character varying(64),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_dec_in; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_dec_in (
    id_ character varying(64) NOT NULL,
    dec_inst_id_ character varying(64) NOT NULL,
    clause_id_ character varying(64),
    clause_name_ character varying(255),
    var_type_ character varying(100),
    bytearray_id_ character varying(64),
    double_ double precision,
    long_ bigint,
    text_ character varying(4000),
    text2_ character varying(4000),
    tenant_id_ character varying(64),
    create_time_ timestamp without time zone,
    root_proc_inst_id_ character varying(64),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_dec_out; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_dec_out (
    id_ character varying(64) NOT NULL,
    dec_inst_id_ character varying(64) NOT NULL,
    clause_id_ character varying(64),
    clause_name_ character varying(255),
    rule_id_ character varying(64),
    rule_order_ integer,
    var_name_ character varying(255),
    var_type_ character varying(100),
    bytearray_id_ character varying(64),
    double_ double precision,
    long_ bigint,
    text_ character varying(4000),
    text2_ character varying(4000),
    tenant_id_ character varying(64),
    create_time_ timestamp without time zone,
    root_proc_inst_id_ character varying(64),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_decinst; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_decinst (
    id_ character varying(64) NOT NULL,
    dec_def_id_ character varying(64) NOT NULL,
    dec_def_key_ character varying(255) NOT NULL,
    dec_def_name_ character varying(255),
    proc_def_key_ character varying(255),
    proc_def_id_ character varying(64),
    proc_inst_id_ character varying(64),
    case_def_key_ character varying(255),
    case_def_id_ character varying(64),
    case_inst_id_ character varying(64),
    act_inst_id_ character varying(64),
    act_id_ character varying(255),
    eval_time_ timestamp without time zone NOT NULL,
    removal_time_ timestamp without time zone,
    collect_value_ double precision,
    user_id_ character varying(255),
    root_dec_inst_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    dec_req_id_ character varying(64),
    dec_req_key_ character varying(255),
    tenant_id_ character varying(64)
);


--
-- Name: act_hi_detail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_detail (
    id_ character varying(64) NOT NULL,
    type_ character varying(255) NOT NULL,
    proc_def_key_ character varying(255),
    proc_def_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    execution_id_ character varying(64),
    case_def_key_ character varying(255),
    case_def_id_ character varying(64),
    case_inst_id_ character varying(64),
    case_execution_id_ character varying(64),
    task_id_ character varying(64),
    act_inst_id_ character varying(64),
    var_inst_id_ character varying(64),
    name_ character varying(255) NOT NULL,
    var_type_ character varying(64),
    rev_ integer,
    time_ timestamp without time zone NOT NULL,
    bytearray_id_ character varying(64),
    double_ double precision,
    long_ bigint,
    text_ character varying(4000),
    text2_ character varying(4000),
    sequence_counter_ bigint,
    tenant_id_ character varying(64),
    operation_id_ character varying(64),
    removal_time_ timestamp without time zone,
    initial_ boolean
);


--
-- Name: act_hi_ext_task_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_ext_task_log (
    id_ character varying(64) NOT NULL,
    timestamp_ timestamp without time zone NOT NULL,
    ext_task_id_ character varying(64) NOT NULL,
    retries_ integer,
    topic_name_ character varying(255),
    worker_id_ character varying(255),
    priority_ bigint DEFAULT 0 NOT NULL,
    error_msg_ character varying(4000),
    error_details_id_ character varying(64),
    act_id_ character varying(255),
    act_inst_id_ character varying(64),
    execution_id_ character varying(64),
    proc_inst_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_def_id_ character varying(64),
    proc_def_key_ character varying(255),
    tenant_id_ character varying(64),
    state_ integer,
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_identitylink; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_identitylink (
    id_ character varying(64) NOT NULL,
    timestamp_ timestamp without time zone NOT NULL,
    type_ character varying(255),
    user_id_ character varying(255),
    group_id_ character varying(255),
    task_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_def_id_ character varying(64),
    operation_type_ character varying(64),
    assigner_id_ character varying(64),
    proc_def_key_ character varying(255),
    tenant_id_ character varying(64),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_incident; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_incident (
    id_ character varying(64) NOT NULL,
    proc_def_key_ character varying(255),
    proc_def_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    execution_id_ character varying(64),
    create_time_ timestamp without time zone NOT NULL,
    end_time_ timestamp without time zone,
    incident_msg_ character varying(4000),
    incident_type_ character varying(255) NOT NULL,
    activity_id_ character varying(255),
    failed_activity_id_ character varying(255),
    cause_incident_id_ character varying(64),
    root_cause_incident_id_ character varying(64),
    configuration_ character varying(255),
    history_configuration_ character varying(255),
    incident_state_ integer,
    tenant_id_ character varying(64),
    job_def_id_ character varying(64),
    annotation_ character varying(4000),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_job_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_job_log (
    id_ character varying(64) NOT NULL,
    timestamp_ timestamp without time zone NOT NULL,
    job_id_ character varying(64) NOT NULL,
    job_duedate_ timestamp without time zone,
    job_retries_ integer,
    job_priority_ bigint DEFAULT 0 NOT NULL,
    job_exception_msg_ character varying(4000),
    job_exception_stack_id_ character varying(64),
    job_state_ integer,
    job_def_id_ character varying(64),
    job_def_type_ character varying(255),
    job_def_configuration_ character varying(255),
    act_id_ character varying(255),
    failed_act_id_ character varying(255),
    execution_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    process_instance_id_ character varying(64),
    process_def_id_ character varying(64),
    process_def_key_ character varying(255),
    deployment_id_ character varying(64),
    sequence_counter_ bigint,
    tenant_id_ character varying(64),
    hostname_ character varying(255),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_op_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_op_log (
    id_ character varying(64) NOT NULL,
    deployment_id_ character varying(64),
    proc_def_id_ character varying(64),
    proc_def_key_ character varying(255),
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    execution_id_ character varying(64),
    case_def_id_ character varying(64),
    case_inst_id_ character varying(64),
    case_execution_id_ character varying(64),
    task_id_ character varying(64),
    job_id_ character varying(64),
    job_def_id_ character varying(64),
    batch_id_ character varying(64),
    user_id_ character varying(255),
    timestamp_ timestamp without time zone NOT NULL,
    operation_type_ character varying(64),
    operation_id_ character varying(64),
    entity_type_ character varying(30),
    property_ character varying(64),
    org_value_ character varying(4000),
    new_value_ character varying(4000),
    tenant_id_ character varying(64),
    removal_time_ timestamp without time zone,
    category_ character varying(64),
    external_task_id_ character varying(64),
    annotation_ character varying(4000)
);


--
-- Name: act_hi_procinst; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_procinst (
    id_ character varying(64) NOT NULL,
    proc_inst_id_ character varying(64) NOT NULL,
    business_key_ character varying(255),
    proc_def_key_ character varying(255),
    proc_def_id_ character varying(64) NOT NULL,
    start_time_ timestamp without time zone NOT NULL,
    end_time_ timestamp without time zone,
    removal_time_ timestamp without time zone,
    duration_ bigint,
    start_user_id_ character varying(255),
    start_act_id_ character varying(255),
    end_act_id_ character varying(255),
    super_process_instance_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    super_case_instance_id_ character varying(64),
    case_inst_id_ character varying(64),
    delete_reason_ character varying(4000),
    tenant_id_ character varying(64),
    state_ character varying(255)
);


--
-- Name: act_hi_taskinst; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_taskinst (
    id_ character varying(64) NOT NULL,
    task_def_key_ character varying(255),
    proc_def_key_ character varying(255),
    proc_def_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    execution_id_ character varying(64),
    case_def_key_ character varying(255),
    case_def_id_ character varying(64),
    case_inst_id_ character varying(64),
    case_execution_id_ character varying(64),
    act_inst_id_ character varying(64),
    name_ character varying(255),
    parent_task_id_ character varying(64),
    description_ character varying(4000),
    owner_ character varying(255),
    assignee_ character varying(255),
    start_time_ timestamp without time zone NOT NULL,
    end_time_ timestamp without time zone,
    duration_ bigint,
    delete_reason_ character varying(4000),
    priority_ integer,
    due_date_ timestamp without time zone,
    follow_up_date_ timestamp without time zone,
    tenant_id_ character varying(64),
    removal_time_ timestamp without time zone
);


--
-- Name: act_hi_varinst; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_hi_varinst (
    id_ character varying(64) NOT NULL,
    proc_def_key_ character varying(255),
    proc_def_id_ character varying(64),
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    execution_id_ character varying(64),
    act_inst_id_ character varying(64),
    case_def_key_ character varying(255),
    case_def_id_ character varying(64),
    case_inst_id_ character varying(64),
    case_execution_id_ character varying(64),
    task_id_ character varying(64),
    name_ character varying(255) NOT NULL,
    var_type_ character varying(100),
    create_time_ timestamp without time zone,
    rev_ integer,
    bytearray_id_ character varying(64),
    double_ double precision,
    long_ bigint,
    text_ character varying(4000),
    text2_ character varying(4000),
    tenant_id_ character varying(64),
    state_ character varying(20),
    removal_time_ timestamp without time zone
);


--
-- Name: act_id_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_id_group (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    name_ character varying(255),
    type_ character varying(255)
);


--
-- Name: act_id_info; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_id_info (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    user_id_ character varying(64),
    type_ character varying(64),
    key_ character varying(255),
    value_ character varying(255),
    password_ bytea,
    parent_id_ character varying(255)
);


--
-- Name: act_id_membership; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_id_membership (
    user_id_ character varying(64) NOT NULL,
    group_id_ character varying(64) NOT NULL
);


--
-- Name: act_id_tenant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_id_tenant (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    name_ character varying(255)
);


--
-- Name: act_id_tenant_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_id_tenant_member (
    id_ character varying(64) NOT NULL,
    tenant_id_ character varying(64) NOT NULL,
    user_id_ character varying(64),
    group_id_ character varying(64)
);


--
-- Name: act_id_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_id_user (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    first_ character varying(255),
    last_ character varying(255),
    email_ character varying(255),
    pwd_ character varying(255),
    salt_ character varying(255),
    lock_exp_time_ timestamp without time zone,
    attempts_ integer,
    picture_id_ character varying(64)
);


--
-- Name: act_re_camformdef; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_re_camformdef (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    key_ character varying(255) NOT NULL,
    version_ integer NOT NULL,
    deployment_id_ character varying(64),
    resource_name_ character varying(4000),
    tenant_id_ character varying(64)
);


--
-- Name: act_re_case_def; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_re_case_def (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    category_ character varying(255),
    name_ character varying(255),
    key_ character varying(255) NOT NULL,
    version_ integer NOT NULL,
    deployment_id_ character varying(64),
    resource_name_ character varying(4000),
    dgrm_resource_name_ character varying(4000),
    tenant_id_ character varying(64),
    history_ttl_ integer
);


--
-- Name: act_re_decision_def; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_re_decision_def (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    category_ character varying(255),
    name_ character varying(255),
    key_ character varying(255) NOT NULL,
    version_ integer NOT NULL,
    deployment_id_ character varying(64),
    resource_name_ character varying(4000),
    dgrm_resource_name_ character varying(4000),
    dec_req_id_ character varying(64),
    dec_req_key_ character varying(255),
    tenant_id_ character varying(64),
    history_ttl_ integer,
    version_tag_ character varying(64)
);


--
-- Name: act_re_decision_req_def; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_re_decision_req_def (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    category_ character varying(255),
    name_ character varying(255),
    key_ character varying(255) NOT NULL,
    version_ integer NOT NULL,
    deployment_id_ character varying(64),
    resource_name_ character varying(4000),
    dgrm_resource_name_ character varying(4000),
    tenant_id_ character varying(64)
);


--
-- Name: act_re_deployment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_re_deployment (
    id_ character varying(64) NOT NULL,
    name_ character varying(255),
    deploy_time_ timestamp without time zone,
    source_ character varying(255),
    tenant_id_ character varying(64)
);


--
-- Name: act_re_procdef; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_re_procdef (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    category_ character varying(255),
    name_ character varying(255),
    key_ character varying(255) NOT NULL,
    version_ integer NOT NULL,
    deployment_id_ character varying(64),
    resource_name_ character varying(4000),
    dgrm_resource_name_ character varying(4000),
    has_start_form_key_ boolean,
    suspension_state_ integer,
    tenant_id_ character varying(64),
    version_tag_ character varying(64),
    history_ttl_ integer,
    startable_ boolean DEFAULT true NOT NULL
);


--
-- Name: act_ru_authorization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_authorization (
    id_ character varying(64) NOT NULL,
    rev_ integer NOT NULL,
    type_ integer NOT NULL,
    group_id_ character varying(255),
    user_id_ character varying(255),
    resource_type_ integer NOT NULL,
    resource_id_ character varying(255),
    perms_ integer,
    removal_time_ timestamp without time zone,
    root_proc_inst_id_ character varying(64)
);


--
-- Name: act_ru_batch; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_batch (
    id_ character varying(64) NOT NULL,
    rev_ integer NOT NULL,
    type_ character varying(255),
    total_jobs_ integer,
    jobs_created_ integer,
    jobs_per_seed_ integer,
    invocations_per_job_ integer,
    seed_job_def_id_ character varying(64),
    batch_job_def_id_ character varying(64),
    monitor_job_def_id_ character varying(64),
    suspension_state_ integer,
    configuration_ character varying(255),
    tenant_id_ character varying(64),
    create_user_id_ character varying(255),
    start_time_ timestamp without time zone,
    exec_start_time_ timestamp without time zone
);


--
-- Name: act_ru_case_execution; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_case_execution (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    case_inst_id_ character varying(64),
    super_case_exec_ character varying(64),
    super_exec_ character varying(64),
    business_key_ character varying(255),
    parent_id_ character varying(64),
    case_def_id_ character varying(64),
    act_id_ character varying(255),
    prev_state_ integer,
    current_state_ integer,
    required_ boolean,
    tenant_id_ character varying(64)
);


--
-- Name: act_ru_case_sentry_part; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_case_sentry_part (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    case_inst_id_ character varying(64),
    case_exec_id_ character varying(64),
    sentry_id_ character varying(255),
    type_ character varying(255),
    source_case_exec_id_ character varying(64),
    standard_event_ character varying(255),
    source_ character varying(255),
    variable_event_ character varying(255),
    variable_name_ character varying(255),
    satisfied_ boolean,
    tenant_id_ character varying(64)
);


--
-- Name: act_ru_event_subscr; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_event_subscr (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    event_type_ character varying(255) NOT NULL,
    event_name_ character varying(255),
    execution_id_ character varying(64),
    proc_inst_id_ character varying(64),
    activity_id_ character varying(255),
    configuration_ character varying(255),
    created_ timestamp without time zone NOT NULL,
    tenant_id_ character varying(64)
);


--
-- Name: act_ru_execution; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_execution (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    root_proc_inst_id_ character varying(64),
    proc_inst_id_ character varying(64),
    business_key_ character varying(255),
    parent_id_ character varying(64),
    proc_def_id_ character varying(64),
    super_exec_ character varying(64),
    super_case_exec_ character varying(64),
    case_inst_id_ character varying(64),
    act_id_ character varying(255),
    act_inst_id_ character varying(64),
    is_active_ boolean,
    is_concurrent_ boolean,
    is_scope_ boolean,
    is_event_scope_ boolean,
    suspension_state_ integer,
    cached_ent_state_ integer,
    sequence_counter_ bigint,
    tenant_id_ character varying(64)
);


--
-- Name: act_ru_ext_task; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_ext_task (
    id_ character varying(64) NOT NULL,
    rev_ integer NOT NULL,
    worker_id_ character varying(255),
    topic_name_ character varying(255),
    retries_ integer,
    error_msg_ character varying(4000),
    error_details_id_ character varying(64),
    lock_exp_time_ timestamp without time zone,
    suspension_state_ integer,
    execution_id_ character varying(64),
    proc_inst_id_ character varying(64),
    proc_def_id_ character varying(64),
    proc_def_key_ character varying(255),
    act_id_ character varying(255),
    act_inst_id_ character varying(64),
    tenant_id_ character varying(64),
    priority_ bigint DEFAULT 0 NOT NULL,
    last_failure_log_id_ character varying(64)
);


--
-- Name: act_ru_filter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_filter (
    id_ character varying(64) NOT NULL,
    rev_ integer NOT NULL,
    resource_type_ character varying(255) NOT NULL,
    name_ character varying(255) NOT NULL,
    owner_ character varying(255),
    query_ text NOT NULL,
    properties_ text
);


--
-- Name: act_ru_identitylink; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_identitylink (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    group_id_ character varying(255),
    type_ character varying(255),
    user_id_ character varying(255),
    task_id_ character varying(64),
    proc_def_id_ character varying(64),
    tenant_id_ character varying(64)
);


--
-- Name: act_ru_incident; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_incident (
    id_ character varying(64) NOT NULL,
    rev_ integer NOT NULL,
    incident_timestamp_ timestamp without time zone NOT NULL,
    incident_msg_ character varying(4000),
    incident_type_ character varying(255) NOT NULL,
    execution_id_ character varying(64),
    activity_id_ character varying(255),
    failed_activity_id_ character varying(255),
    proc_inst_id_ character varying(64),
    proc_def_id_ character varying(64),
    cause_incident_id_ character varying(64),
    root_cause_incident_id_ character varying(64),
    configuration_ character varying(255),
    tenant_id_ character varying(64),
    job_def_id_ character varying(64),
    annotation_ character varying(4000)
);


--
-- Name: act_ru_job; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_job (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    type_ character varying(255) NOT NULL,
    lock_exp_time_ timestamp without time zone,
    lock_owner_ character varying(255),
    exclusive_ boolean,
    execution_id_ character varying(64),
    process_instance_id_ character varying(64),
    process_def_id_ character varying(64),
    process_def_key_ character varying(255),
    retries_ integer,
    exception_stack_id_ character varying(64),
    exception_msg_ character varying(4000),
    failed_act_id_ character varying(255),
    duedate_ timestamp without time zone,
    repeat_ character varying(255),
    repeat_offset_ bigint DEFAULT 0,
    handler_type_ character varying(255),
    handler_cfg_ character varying(4000),
    deployment_id_ character varying(64),
    suspension_state_ integer DEFAULT 1 NOT NULL,
    job_def_id_ character varying(64),
    priority_ bigint DEFAULT 0 NOT NULL,
    sequence_counter_ bigint,
    tenant_id_ character varying(64),
    create_time_ timestamp without time zone,
    last_failure_log_id_ character varying(64)
);


--
-- Name: act_ru_jobdef; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_jobdef (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    proc_def_id_ character varying(64),
    proc_def_key_ character varying(255),
    act_id_ character varying(255),
    job_type_ character varying(255) NOT NULL,
    job_configuration_ character varying(255),
    suspension_state_ integer,
    job_priority_ bigint,
    tenant_id_ character varying(64),
    deployment_id_ character varying(64)
);


--
-- Name: act_ru_meter_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_meter_log (
    id_ character varying(64) NOT NULL,
    name_ character varying(64) NOT NULL,
    reporter_ character varying(255),
    value_ bigint,
    timestamp_ timestamp without time zone,
    milliseconds_ bigint DEFAULT 0
);


--
-- Name: act_ru_task; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_task (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    execution_id_ character varying(64),
    proc_inst_id_ character varying(64),
    proc_def_id_ character varying(64),
    case_execution_id_ character varying(64),
    case_inst_id_ character varying(64),
    case_def_id_ character varying(64),
    name_ character varying(255),
    parent_task_id_ character varying(64),
    description_ character varying(4000),
    task_def_key_ character varying(255),
    owner_ character varying(255),
    assignee_ character varying(255),
    delegation_ character varying(64),
    priority_ integer,
    create_time_ timestamp without time zone,
    last_updated_ timestamp without time zone,
    due_date_ timestamp without time zone,
    follow_up_date_ timestamp without time zone,
    suspension_state_ integer,
    tenant_id_ character varying(64)
);


--
-- Name: act_ru_task_meter_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_task_meter_log (
    id_ character varying(64) NOT NULL,
    assignee_hash_ bigint,
    timestamp_ timestamp without time zone
);


--
-- Name: act_ru_variable; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_ru_variable (
    id_ character varying(64) NOT NULL,
    rev_ integer,
    type_ character varying(255) NOT NULL,
    name_ character varying(255) NOT NULL,
    execution_id_ character varying(64),
    proc_inst_id_ character varying(64),
    proc_def_id_ character varying(64),
    case_execution_id_ character varying(64),
    case_inst_id_ character varying(64),
    task_id_ character varying(64),
    batch_id_ character varying(64),
    bytearray_id_ character varying(64),
    double_ double precision,
    long_ bigint,
    text_ character varying(4000),
    text2_ character varying(4000),
    var_scope_ character varying(64),
    sequence_counter_ bigint,
    is_concurrent_local_ boolean,
    tenant_id_ character varying(64)
);


--
-- Name: seq_dict_materials; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seq_dict_materials
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dict_materials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dict_materials (
    id numeric(15,0) DEFAULT nextval('public.seq_dict_materials'::regclass) NOT NULL,
    name character varying,
    caption character varying,
    description text
);


--
-- Name: TABLE dict_materials; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.dict_materials IS 'Материалы';


--
-- Name: COLUMN dict_materials.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dict_materials.id IS 'Код';


--
-- Name: COLUMN dict_materials.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dict_materials.name IS 'Краткое имя';


--
-- Name: COLUMN dict_materials.caption; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dict_materials.caption IS 'Наименование';


--
-- Name: COLUMN dict_materials.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dict_materials.description IS 'Описание';


--
-- Name: seq_dict_store_operation; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seq_dict_store_operation
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dict_store_operation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dict_store_operation (
    id numeric(15,0) DEFAULT nextval('public.seq_dict_store_operation'::regclass) NOT NULL,
    operation_type character varying(32) DEFAULT 'ADD'::character varying NOT NULL,
    material_id numeric(15,0) NOT NULL,
    amount numeric(15,4) DEFAULT 0 NOT NULL,
    operation_date_time timestamp without time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: TABLE dict_store_operation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.dict_store_operation IS 'Складские операции';


--
-- Name: COLUMN dict_store_operation.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dict_store_operation.id IS 'Код';


--
-- Name: COLUMN dict_store_operation.operation_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dict_store_operation.operation_type IS 'ADD or REMOVE';


--
-- Name: COLUMN dict_store_operation.material_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dict_store_operation.material_id IS 'Код материала';


--
-- Name: COLUMN dict_store_operation.amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dict_store_operation.amount IS 'Количество в операции';


--
-- Name: COLUMN dict_store_operation.operation_date_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dict_store_operation.operation_date_time IS 'Дата/Время операции';


--
-- Name: seq_dict_storehouse; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seq_dict_storehouse
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dict_storehouse; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dict_storehouse (
    id numeric(15,0) DEFAULT nextval('public.seq_dict_storehouse'::regclass) NOT NULL,
    material_id numeric(15,0) NOT NULL,
    amount numeric(15,4) DEFAULT 0 NOT NULL
);


--
-- Name: TABLE dict_storehouse; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.dict_storehouse IS 'Хранилище';


--
-- Name: COLUMN dict_storehouse.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dict_storehouse.id IS 'Код';


--
-- Name: COLUMN dict_storehouse.material_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dict_storehouse.material_id IS 'Код материала';


--
-- Name: COLUMN dict_storehouse.amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.dict_storehouse.amount IS 'Количество материала';


--
-- Data for Name: act_ge_bytearray; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ge_bytearray (id_, rev_, name_, deployment_id_, bytes_, generated_, tenant_id_, type_, create_time_, root_proc_inst_id_, removal_time_) FROM stdin;
\.
COPY public.act_ge_bytearray (id_, rev_, name_, deployment_id_, bytes_, generated_, tenant_id_, type_, create_time_, root_proc_inst_id_, removal_time_) FROM '$$PATH$$/3593.dat';

--
-- Data for Name: act_ge_property; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ge_property (name_, value_, rev_) FROM stdin;
\.
COPY public.act_ge_property (name_, value_, rev_) FROM '$$PATH$$/3592.dat';

--
-- Data for Name: act_ge_schema_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ge_schema_log (id_, timestamp_, version_) FROM stdin;
\.
COPY public.act_ge_schema_log (id_, timestamp_, version_) FROM '$$PATH$$/3594.dat';

--
-- Data for Name: act_hi_actinst; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_actinst (id_, parent_act_inst_id_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, act_id_, task_id_, call_proc_inst_id_, call_case_inst_id_, act_name_, act_type_, assignee_, start_time_, end_time_, duration_, act_inst_state_, sequence_counter_, tenant_id_, removal_time_) FROM stdin;
\.
COPY public.act_hi_actinst (id_, parent_act_inst_id_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, act_id_, task_id_, call_proc_inst_id_, call_case_inst_id_, act_name_, act_type_, assignee_, start_time_, end_time_, duration_, act_inst_state_, sequence_counter_, tenant_id_, removal_time_) FROM '$$PATH$$/3613.dat';

--
-- Data for Name: act_hi_attachment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_attachment (id_, rev_, user_id_, name_, description_, type_, task_id_, root_proc_inst_id_, proc_inst_id_, url_, content_id_, tenant_id_, create_time_, removal_time_) FROM stdin;
\.
COPY public.act_hi_attachment (id_, rev_, user_id_, name_, description_, type_, task_id_, root_proc_inst_id_, proc_inst_id_, url_, content_id_, tenant_id_, create_time_, removal_time_) FROM '$$PATH$$/3619.dat';

--
-- Data for Name: act_hi_batch; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_batch (id_, type_, total_jobs_, jobs_per_seed_, invocations_per_job_, seed_job_def_id_, monitor_job_def_id_, batch_job_def_id_, tenant_id_, create_user_id_, start_time_, end_time_, removal_time_, exec_start_time_) FROM stdin;
\.
COPY public.act_hi_batch (id_, type_, total_jobs_, jobs_per_seed_, invocations_per_job_, seed_job_def_id_, monitor_job_def_id_, batch_job_def_id_, tenant_id_, create_user_id_, start_time_, end_time_, removal_time_, exec_start_time_) FROM '$$PATH$$/3623.dat';

--
-- Data for Name: act_hi_caseactinst; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_caseactinst (id_, parent_act_inst_id_, case_def_id_, case_inst_id_, case_act_id_, task_id_, call_proc_inst_id_, call_case_inst_id_, case_act_name_, case_act_type_, create_time_, end_time_, duration_, state_, required_, tenant_id_) FROM stdin;
\.
COPY public.act_hi_caseactinst (id_, parent_act_inst_id_, case_def_id_, case_inst_id_, case_act_id_, task_id_, call_proc_inst_id_, call_case_inst_id_, case_act_name_, case_act_type_, create_time_, end_time_, duration_, state_, required_, tenant_id_) FROM '$$PATH$$/3635.dat';

--
-- Data for Name: act_hi_caseinst; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_caseinst (id_, case_inst_id_, business_key_, case_def_id_, create_time_, close_time_, duration_, state_, create_user_id_, super_case_instance_id_, super_process_instance_id_, tenant_id_) FROM stdin;
\.
COPY public.act_hi_caseinst (id_, case_inst_id_, business_key_, case_def_id_, create_time_, close_time_, duration_, state_, create_user_id_, super_case_instance_id_, super_process_instance_id_, tenant_id_) FROM '$$PATH$$/3634.dat';

--
-- Data for Name: act_hi_comment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_comment (id_, type_, time_, user_id_, task_id_, root_proc_inst_id_, proc_inst_id_, action_, message_, full_msg_, tenant_id_, removal_time_) FROM stdin;
\.
COPY public.act_hi_comment (id_, type_, time_, user_id_, task_id_, root_proc_inst_id_, proc_inst_id_, action_, message_, full_msg_, tenant_id_, removal_time_) FROM '$$PATH$$/3618.dat';

--
-- Data for Name: act_hi_dec_in; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_dec_in (id_, dec_inst_id_, clause_id_, clause_name_, var_type_, bytearray_id_, double_, long_, text_, text2_, tenant_id_, create_time_, root_proc_inst_id_, removal_time_) FROM stdin;
\.
COPY public.act_hi_dec_in (id_, dec_inst_id_, clause_id_, clause_name_, var_type_, bytearray_id_, double_, long_, text_, text2_, tenant_id_, create_time_, root_proc_inst_id_, removal_time_) FROM '$$PATH$$/3639.dat';

--
-- Data for Name: act_hi_dec_out; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_dec_out (id_, dec_inst_id_, clause_id_, clause_name_, rule_id_, rule_order_, var_name_, var_type_, bytearray_id_, double_, long_, text_, text2_, tenant_id_, create_time_, root_proc_inst_id_, removal_time_) FROM stdin;
\.
COPY public.act_hi_dec_out (id_, dec_inst_id_, clause_id_, clause_name_, rule_id_, rule_order_, var_name_, var_type_, bytearray_id_, double_, long_, text_, text2_, tenant_id_, create_time_, root_proc_inst_id_, removal_time_) FROM '$$PATH$$/3640.dat';

--
-- Data for Name: act_hi_decinst; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_decinst (id_, dec_def_id_, dec_def_key_, dec_def_name_, proc_def_key_, proc_def_id_, proc_inst_id_, case_def_key_, case_def_id_, case_inst_id_, act_inst_id_, act_id_, eval_time_, removal_time_, collect_value_, user_id_, root_dec_inst_id_, root_proc_inst_id_, dec_req_id_, dec_req_key_, tenant_id_) FROM stdin;
\.
COPY public.act_hi_decinst (id_, dec_def_id_, dec_def_key_, dec_def_name_, proc_def_key_, proc_def_id_, proc_inst_id_, case_def_key_, case_def_id_, case_inst_id_, act_inst_id_, act_id_, eval_time_, removal_time_, collect_value_, user_id_, root_dec_inst_id_, root_proc_inst_id_, dec_req_id_, dec_req_key_, tenant_id_) FROM '$$PATH$$/3638.dat';

--
-- Data for Name: act_hi_detail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_detail (id_, type_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, case_def_key_, case_def_id_, case_inst_id_, case_execution_id_, task_id_, act_inst_id_, var_inst_id_, name_, var_type_, rev_, time_, bytearray_id_, double_, long_, text_, text2_, sequence_counter_, tenant_id_, operation_id_, removal_time_, initial_) FROM stdin;
\.
COPY public.act_hi_detail (id_, type_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, case_def_key_, case_def_id_, case_inst_id_, case_execution_id_, task_id_, act_inst_id_, var_inst_id_, name_, var_type_, rev_, time_, bytearray_id_, double_, long_, text_, text2_, sequence_counter_, tenant_id_, operation_id_, removal_time_, initial_) FROM '$$PATH$$/3616.dat';

--
-- Data for Name: act_hi_ext_task_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_ext_task_log (id_, timestamp_, ext_task_id_, retries_, topic_name_, worker_id_, priority_, error_msg_, error_details_id_, act_id_, act_inst_id_, execution_id_, proc_inst_id_, root_proc_inst_id_, proc_def_id_, proc_def_key_, tenant_id_, state_, removal_time_) FROM stdin;
\.
COPY public.act_hi_ext_task_log (id_, timestamp_, ext_task_id_, retries_, topic_name_, worker_id_, priority_, error_msg_, error_details_id_, act_id_, act_inst_id_, execution_id_, proc_inst_id_, root_proc_inst_id_, proc_def_id_, proc_def_key_, tenant_id_, state_, removal_time_) FROM '$$PATH$$/3624.dat';

--
-- Data for Name: act_hi_identitylink; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_identitylink (id_, timestamp_, type_, user_id_, group_id_, task_id_, root_proc_inst_id_, proc_def_id_, operation_type_, assigner_id_, proc_def_key_, tenant_id_, removal_time_) FROM stdin;
\.
COPY public.act_hi_identitylink (id_, timestamp_, type_, user_id_, group_id_, task_id_, root_proc_inst_id_, proc_def_id_, operation_type_, assigner_id_, proc_def_key_, tenant_id_, removal_time_) FROM '$$PATH$$/3617.dat';

--
-- Data for Name: act_hi_incident; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_incident (id_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, create_time_, end_time_, incident_msg_, incident_type_, activity_id_, failed_activity_id_, cause_incident_id_, root_cause_incident_id_, configuration_, history_configuration_, incident_state_, tenant_id_, job_def_id_, annotation_, removal_time_) FROM stdin;
\.
COPY public.act_hi_incident (id_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, create_time_, end_time_, incident_msg_, incident_type_, activity_id_, failed_activity_id_, cause_incident_id_, root_cause_incident_id_, configuration_, history_configuration_, incident_state_, tenant_id_, job_def_id_, annotation_, removal_time_) FROM '$$PATH$$/3621.dat';

--
-- Data for Name: act_hi_job_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_job_log (id_, timestamp_, job_id_, job_duedate_, job_retries_, job_priority_, job_exception_msg_, job_exception_stack_id_, job_state_, job_def_id_, job_def_type_, job_def_configuration_, act_id_, failed_act_id_, execution_id_, root_proc_inst_id_, process_instance_id_, process_def_id_, process_def_key_, deployment_id_, sequence_counter_, tenant_id_, hostname_, removal_time_) FROM stdin;
\.
COPY public.act_hi_job_log (id_, timestamp_, job_id_, job_duedate_, job_retries_, job_priority_, job_exception_msg_, job_exception_stack_id_, job_state_, job_def_id_, job_def_type_, job_def_configuration_, act_id_, failed_act_id_, execution_id_, root_proc_inst_id_, process_instance_id_, process_def_id_, process_def_key_, deployment_id_, sequence_counter_, tenant_id_, hostname_, removal_time_) FROM '$$PATH$$/3622.dat';

--
-- Data for Name: act_hi_op_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_op_log (id_, deployment_id_, proc_def_id_, proc_def_key_, root_proc_inst_id_, proc_inst_id_, execution_id_, case_def_id_, case_inst_id_, case_execution_id_, task_id_, job_id_, job_def_id_, batch_id_, user_id_, timestamp_, operation_type_, operation_id_, entity_type_, property_, org_value_, new_value_, tenant_id_, removal_time_, category_, external_task_id_, annotation_) FROM stdin;
\.
COPY public.act_hi_op_log (id_, deployment_id_, proc_def_id_, proc_def_key_, root_proc_inst_id_, proc_inst_id_, execution_id_, case_def_id_, case_inst_id_, case_execution_id_, task_id_, job_id_, job_def_id_, batch_id_, user_id_, timestamp_, operation_type_, operation_id_, entity_type_, property_, org_value_, new_value_, tenant_id_, removal_time_, category_, external_task_id_, annotation_) FROM '$$PATH$$/3620.dat';

--
-- Data for Name: act_hi_procinst; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_procinst (id_, proc_inst_id_, business_key_, proc_def_key_, proc_def_id_, start_time_, end_time_, removal_time_, duration_, start_user_id_, start_act_id_, end_act_id_, super_process_instance_id_, root_proc_inst_id_, super_case_instance_id_, case_inst_id_, delete_reason_, tenant_id_, state_) FROM stdin;
\.
COPY public.act_hi_procinst (id_, proc_inst_id_, business_key_, proc_def_key_, proc_def_id_, start_time_, end_time_, removal_time_, duration_, start_user_id_, start_act_id_, end_act_id_, super_process_instance_id_, root_proc_inst_id_, super_case_instance_id_, case_inst_id_, delete_reason_, tenant_id_, state_) FROM '$$PATH$$/3612.dat';

--
-- Data for Name: act_hi_taskinst; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_taskinst (id_, task_def_key_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, case_def_key_, case_def_id_, case_inst_id_, case_execution_id_, act_inst_id_, name_, parent_task_id_, description_, owner_, assignee_, start_time_, end_time_, duration_, delete_reason_, priority_, due_date_, follow_up_date_, tenant_id_, removal_time_) FROM stdin;
\.
COPY public.act_hi_taskinst (id_, task_def_key_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, case_def_key_, case_def_id_, case_inst_id_, case_execution_id_, act_inst_id_, name_, parent_task_id_, description_, owner_, assignee_, start_time_, end_time_, duration_, delete_reason_, priority_, due_date_, follow_up_date_, tenant_id_, removal_time_) FROM '$$PATH$$/3614.dat';

--
-- Data for Name: act_hi_varinst; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_hi_varinst (id_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, act_inst_id_, case_def_key_, case_def_id_, case_inst_id_, case_execution_id_, task_id_, name_, var_type_, create_time_, rev_, bytearray_id_, double_, long_, text_, text2_, tenant_id_, state_, removal_time_) FROM stdin;
\.
COPY public.act_hi_varinst (id_, proc_def_key_, proc_def_id_, root_proc_inst_id_, proc_inst_id_, execution_id_, act_inst_id_, case_def_key_, case_def_id_, case_inst_id_, case_execution_id_, task_id_, name_, var_type_, create_time_, rev_, bytearray_id_, double_, long_, text_, text2_, tenant_id_, state_, removal_time_) FROM '$$PATH$$/3615.dat';

--
-- Data for Name: act_id_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_id_group (id_, rev_, name_, type_) FROM stdin;
\.
COPY public.act_id_group (id_, rev_, name_, type_) FROM '$$PATH$$/3625.dat';

--
-- Data for Name: act_id_info; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_id_info (id_, rev_, user_id_, type_, key_, value_, password_, parent_id_) FROM stdin;
\.
COPY public.act_id_info (id_, rev_, user_id_, type_, key_, value_, password_, parent_id_) FROM '$$PATH$$/3628.dat';

--
-- Data for Name: act_id_membership; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_id_membership (user_id_, group_id_) FROM stdin;
\.
COPY public.act_id_membership (user_id_, group_id_) FROM '$$PATH$$/3626.dat';

--
-- Data for Name: act_id_tenant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_id_tenant (id_, rev_, name_) FROM stdin;
\.
COPY public.act_id_tenant (id_, rev_, name_) FROM '$$PATH$$/3629.dat';

--
-- Data for Name: act_id_tenant_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_id_tenant_member (id_, tenant_id_, user_id_, group_id_) FROM stdin;
\.
COPY public.act_id_tenant_member (id_, tenant_id_, user_id_, group_id_) FROM '$$PATH$$/3630.dat';

--
-- Data for Name: act_id_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_id_user (id_, rev_, first_, last_, email_, pwd_, salt_, lock_exp_time_, attempts_, picture_id_) FROM stdin;
\.
COPY public.act_id_user (id_, rev_, first_, last_, email_, pwd_, salt_, lock_exp_time_, attempts_, picture_id_) FROM '$$PATH$$/3627.dat';

--
-- Data for Name: act_re_camformdef; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_re_camformdef (id_, rev_, key_, version_, deployment_id_, resource_name_, tenant_id_) FROM stdin;
\.
COPY public.act_re_camformdef (id_, rev_, key_, version_, deployment_id_, resource_name_, tenant_id_) FROM '$$PATH$$/3600.dat';

--
-- Data for Name: act_re_case_def; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_re_case_def (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, tenant_id_, history_ttl_) FROM stdin;
\.
COPY public.act_re_case_def (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, tenant_id_, history_ttl_) FROM '$$PATH$$/3631.dat';

--
-- Data for Name: act_re_decision_def; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_re_decision_def (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, dec_req_id_, dec_req_key_, tenant_id_, history_ttl_, version_tag_) FROM stdin;
\.
COPY public.act_re_decision_def (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, dec_req_id_, dec_req_key_, tenant_id_, history_ttl_, version_tag_) FROM '$$PATH$$/3636.dat';

--
-- Data for Name: act_re_decision_req_def; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_re_decision_req_def (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, tenant_id_) FROM stdin;
\.
COPY public.act_re_decision_req_def (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, tenant_id_) FROM '$$PATH$$/3637.dat';

--
-- Data for Name: act_re_deployment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_re_deployment (id_, name_, deploy_time_, source_, tenant_id_) FROM stdin;
\.
COPY public.act_re_deployment (id_, name_, deploy_time_, source_, tenant_id_) FROM '$$PATH$$/3595.dat';

--
-- Data for Name: act_re_procdef; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_re_procdef (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, has_start_form_key_, suspension_state_, tenant_id_, version_tag_, history_ttl_, startable_) FROM stdin;
\.
COPY public.act_re_procdef (id_, rev_, category_, name_, key_, version_, deployment_id_, resource_name_, dgrm_resource_name_, has_start_form_key_, suspension_state_, tenant_id_, version_tag_, history_ttl_, startable_) FROM '$$PATH$$/3599.dat';

--
-- Data for Name: act_ru_authorization; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_authorization (id_, rev_, type_, group_id_, user_id_, resource_type_, resource_id_, perms_, removal_time_, root_proc_inst_id_) FROM stdin;
\.
COPY public.act_ru_authorization (id_, rev_, type_, group_id_, user_id_, resource_type_, resource_id_, perms_, removal_time_, root_proc_inst_id_) FROM '$$PATH$$/3606.dat';

--
-- Data for Name: act_ru_batch; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_batch (id_, rev_, type_, total_jobs_, jobs_created_, jobs_per_seed_, invocations_per_job_, seed_job_def_id_, batch_job_def_id_, monitor_job_def_id_, suspension_state_, configuration_, tenant_id_, create_user_id_, start_time_, exec_start_time_) FROM stdin;
\.
COPY public.act_ru_batch (id_, rev_, type_, total_jobs_, jobs_created_, jobs_per_seed_, invocations_per_job_, seed_job_def_id_, batch_job_def_id_, monitor_job_def_id_, suspension_state_, configuration_, tenant_id_, create_user_id_, start_time_, exec_start_time_) FROM '$$PATH$$/3611.dat';

--
-- Data for Name: act_ru_case_execution; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_case_execution (id_, rev_, case_inst_id_, super_case_exec_, super_exec_, business_key_, parent_id_, case_def_id_, act_id_, prev_state_, current_state_, required_, tenant_id_) FROM stdin;
\.
COPY public.act_ru_case_execution (id_, rev_, case_inst_id_, super_case_exec_, super_exec_, business_key_, parent_id_, case_def_id_, act_id_, prev_state_, current_state_, required_, tenant_id_) FROM '$$PATH$$/3632.dat';

--
-- Data for Name: act_ru_case_sentry_part; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_case_sentry_part (id_, rev_, case_inst_id_, case_exec_id_, sentry_id_, type_, source_case_exec_id_, standard_event_, source_, variable_event_, variable_name_, satisfied_, tenant_id_) FROM stdin;
\.
COPY public.act_ru_case_sentry_part (id_, rev_, case_inst_id_, case_exec_id_, sentry_id_, type_, source_case_exec_id_, standard_event_, source_, variable_event_, variable_name_, satisfied_, tenant_id_) FROM '$$PATH$$/3633.dat';

--
-- Data for Name: act_ru_event_subscr; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_event_subscr (id_, rev_, event_type_, event_name_, execution_id_, proc_inst_id_, activity_id_, configuration_, created_, tenant_id_) FROM stdin;
\.
COPY public.act_ru_event_subscr (id_, rev_, event_type_, event_name_, execution_id_, proc_inst_id_, activity_id_, configuration_, created_, tenant_id_) FROM '$$PATH$$/3604.dat';

--
-- Data for Name: act_ru_execution; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_execution (id_, rev_, root_proc_inst_id_, proc_inst_id_, business_key_, parent_id_, proc_def_id_, super_exec_, super_case_exec_, case_inst_id_, act_id_, act_inst_id_, is_active_, is_concurrent_, is_scope_, is_event_scope_, suspension_state_, cached_ent_state_, sequence_counter_, tenant_id_) FROM stdin;
\.
COPY public.act_ru_execution (id_, rev_, root_proc_inst_id_, proc_inst_id_, business_key_, parent_id_, proc_def_id_, super_exec_, super_case_exec_, case_inst_id_, act_id_, act_inst_id_, is_active_, is_concurrent_, is_scope_, is_event_scope_, suspension_state_, cached_ent_state_, sequence_counter_, tenant_id_) FROM '$$PATH$$/3596.dat';

--
-- Data for Name: act_ru_ext_task; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_ext_task (id_, rev_, worker_id_, topic_name_, retries_, error_msg_, error_details_id_, lock_exp_time_, suspension_state_, execution_id_, proc_inst_id_, proc_def_id_, proc_def_key_, act_id_, act_inst_id_, tenant_id_, priority_, last_failure_log_id_) FROM stdin;
\.
COPY public.act_ru_ext_task (id_, rev_, worker_id_, topic_name_, retries_, error_msg_, error_details_id_, lock_exp_time_, suspension_state_, execution_id_, proc_inst_id_, proc_def_id_, proc_def_key_, act_id_, act_inst_id_, tenant_id_, priority_, last_failure_log_id_) FROM '$$PATH$$/3610.dat';

--
-- Data for Name: act_ru_filter; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_filter (id_, rev_, resource_type_, name_, owner_, query_, properties_) FROM stdin;
\.
COPY public.act_ru_filter (id_, rev_, resource_type_, name_, owner_, query_, properties_) FROM '$$PATH$$/3607.dat';

--
-- Data for Name: act_ru_identitylink; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_identitylink (id_, rev_, group_id_, type_, user_id_, task_id_, proc_def_id_, tenant_id_) FROM stdin;
\.
COPY public.act_ru_identitylink (id_, rev_, group_id_, type_, user_id_, task_id_, proc_def_id_, tenant_id_) FROM '$$PATH$$/3602.dat';

--
-- Data for Name: act_ru_incident; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_incident (id_, rev_, incident_timestamp_, incident_msg_, incident_type_, execution_id_, activity_id_, failed_activity_id_, proc_inst_id_, proc_def_id_, cause_incident_id_, root_cause_incident_id_, configuration_, tenant_id_, job_def_id_, annotation_) FROM stdin;
\.
COPY public.act_ru_incident (id_, rev_, incident_timestamp_, incident_msg_, incident_type_, execution_id_, activity_id_, failed_activity_id_, proc_inst_id_, proc_def_id_, cause_incident_id_, root_cause_incident_id_, configuration_, tenant_id_, job_def_id_, annotation_) FROM '$$PATH$$/3605.dat';

--
-- Data for Name: act_ru_job; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_job (id_, rev_, type_, lock_exp_time_, lock_owner_, exclusive_, execution_id_, process_instance_id_, process_def_id_, process_def_key_, retries_, exception_stack_id_, exception_msg_, failed_act_id_, duedate_, repeat_, repeat_offset_, handler_type_, handler_cfg_, deployment_id_, suspension_state_, job_def_id_, priority_, sequence_counter_, tenant_id_, create_time_, last_failure_log_id_) FROM stdin;
\.
COPY public.act_ru_job (id_, rev_, type_, lock_exp_time_, lock_owner_, exclusive_, execution_id_, process_instance_id_, process_def_id_, process_def_key_, retries_, exception_stack_id_, exception_msg_, failed_act_id_, duedate_, repeat_, repeat_offset_, handler_type_, handler_cfg_, deployment_id_, suspension_state_, job_def_id_, priority_, sequence_counter_, tenant_id_, create_time_, last_failure_log_id_) FROM '$$PATH$$/3597.dat';

--
-- Data for Name: act_ru_jobdef; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_jobdef (id_, rev_, proc_def_id_, proc_def_key_, act_id_, job_type_, job_configuration_, suspension_state_, job_priority_, tenant_id_, deployment_id_) FROM stdin;
\.
COPY public.act_ru_jobdef (id_, rev_, proc_def_id_, proc_def_key_, act_id_, job_type_, job_configuration_, suspension_state_, job_priority_, tenant_id_, deployment_id_) FROM '$$PATH$$/3598.dat';

--
-- Data for Name: act_ru_meter_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_meter_log (id_, name_, reporter_, value_, timestamp_, milliseconds_) FROM stdin;
\.
COPY public.act_ru_meter_log (id_, name_, reporter_, value_, timestamp_, milliseconds_) FROM '$$PATH$$/3608.dat';

--
-- Data for Name: act_ru_task; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_task (id_, rev_, execution_id_, proc_inst_id_, proc_def_id_, case_execution_id_, case_inst_id_, case_def_id_, name_, parent_task_id_, description_, task_def_key_, owner_, assignee_, delegation_, priority_, create_time_, last_updated_, due_date_, follow_up_date_, suspension_state_, tenant_id_) FROM stdin;
\.
COPY public.act_ru_task (id_, rev_, execution_id_, proc_inst_id_, proc_def_id_, case_execution_id_, case_inst_id_, case_def_id_, name_, parent_task_id_, description_, task_def_key_, owner_, assignee_, delegation_, priority_, create_time_, last_updated_, due_date_, follow_up_date_, suspension_state_, tenant_id_) FROM '$$PATH$$/3601.dat';

--
-- Data for Name: act_ru_task_meter_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_task_meter_log (id_, assignee_hash_, timestamp_) FROM stdin;
\.
COPY public.act_ru_task_meter_log (id_, assignee_hash_, timestamp_) FROM '$$PATH$$/3609.dat';

--
-- Data for Name: act_ru_variable; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_ru_variable (id_, rev_, type_, name_, execution_id_, proc_inst_id_, proc_def_id_, case_execution_id_, case_inst_id_, task_id_, batch_id_, bytearray_id_, double_, long_, text_, text2_, var_scope_, sequence_counter_, is_concurrent_local_, tenant_id_) FROM stdin;
\.
COPY public.act_ru_variable (id_, rev_, type_, name_, execution_id_, proc_inst_id_, proc_def_id_, case_execution_id_, case_inst_id_, task_id_, batch_id_, bytearray_id_, double_, long_, text_, text2_, var_scope_, sequence_counter_, is_concurrent_local_, tenant_id_) FROM '$$PATH$$/3603.dat';

--
-- Data for Name: dict_materials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dict_materials (id, name, caption, description) FROM stdin;
\.
COPY public.dict_materials (id, name, caption, description) FROM '$$PATH$$/3641.dat';

--
-- Data for Name: dict_store_operation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dict_store_operation (id, operation_type, material_id, amount, operation_date_time) FROM stdin;
\.
COPY public.dict_store_operation (id, operation_type, material_id, amount, operation_date_time) FROM '$$PATH$$/3646.dat';

--
-- Data for Name: dict_storehouse; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dict_storehouse (id, material_id, amount) FROM stdin;
\.
COPY public.dict_storehouse (id, material_id, amount) FROM '$$PATH$$/3644.dat';

--
-- Name: seq_dict_materials; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.seq_dict_materials', 8, true);


--
-- Name: seq_dict_store_operation; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.seq_dict_store_operation', 1, true);


--
-- Name: seq_dict_storehouse; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.seq_dict_storehouse', 1, true);


--
-- Name: act_id_membership act_id_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_id_membership
    ADD CONSTRAINT act_id_membership_pkey PRIMARY KEY (user_id_, group_id_);


--
-- Name: act_idx_hi_act_inst_comp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_comp ON public.act_hi_actinst USING btree (execution_id_, act_id_, end_time_, id_);


--
-- Name: act_idx_hi_act_inst_procinst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_procinst ON public.act_hi_actinst USING btree (proc_inst_id_, act_id_);


--
-- Name: act_idx_hi_act_inst_start_end; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_start_end ON public.act_hi_actinst USING btree (start_time_, end_time_);


--
-- Name: act_idx_hi_act_inst_stats; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_stats ON public.act_hi_actinst USING btree (proc_def_id_, proc_inst_id_, act_id_, end_time_, act_inst_state_);


--
-- Name: act_idx_hi_ai_pdefid_end_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_ai_pdefid_end_time ON public.act_hi_actinst USING btree (proc_def_id_, end_time_);


--
-- Name: act_idx_hi_cas_a_i_comp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_cas_a_i_comp ON public.act_hi_caseactinst USING btree (case_act_id_, end_time_, id_);


--
-- Name: act_idx_hi_dec_in_clause; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_in_clause ON public.act_hi_dec_in USING btree (dec_inst_id_, clause_id_);


--
-- Name: act_idx_hi_dec_out_rule; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_out_rule ON public.act_hi_dec_out USING btree (rule_order_, clause_id_);


--
-- Name: act_idx_hi_detail_task_bytear; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_detail_task_bytear ON public.act_hi_detail USING btree (bytearray_id_, task_id_);


--
-- Name: act_idx_hi_pi_pdefid_end_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_pi_pdefid_end_time ON public.act_hi_procinst USING btree (proc_def_id_, end_time_);


--
-- Name: act_idx_hi_pro_inst_proc_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_pro_inst_proc_time ON public.act_hi_procinst USING btree (start_time_, end_time_);


--
-- Name: act_idx_hi_procvar_name_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_procvar_name_type ON public.act_hi_varinst USING btree (name_, var_type_);


--
-- Name: act_idx_hi_taskinstid_procinst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_taskinstid_procinst ON public.act_hi_taskinst USING btree (id_, proc_inst_id_);


--
-- Name: act_idx_hi_var_pi_name_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_var_pi_name_type ON public.act_hi_varinst USING btree (proc_inst_id_, name_, var_type_);


--
-- Name: act_idx_job_handler; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_job_handler ON public.act_ru_job USING btree (handler_type_, handler_cfg_);


--
-- Name: act_idx_meter_log; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_meter_log ON public.act_ru_meter_log USING btree (name_, timestamp_);


--
-- Name: act_idx_meter_log_name_ms; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_meter_log_name_ms ON public.act_ru_meter_log USING btree (name_, milliseconds_);


--
-- Name: act_idx_meter_log_report; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_meter_log_report ON public.act_ru_meter_log USING btree (name_, reporter_, milliseconds_);


--
-- Name: act_idx_variable_task_name_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_variable_task_name_type ON public.act_ru_variable USING btree (task_id_, name_, type_);


--
-- Name: act_ru_authorization act_uniq_auth_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_authorization
    ADD CONSTRAINT act_uniq_auth_group UNIQUE (type_, group_id_, resource_type_, resource_id_);


--
-- Name: act_ru_authorization act_uniq_auth_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_authorization
    ADD CONSTRAINT act_uniq_auth_user UNIQUE (type_, user_id_, resource_type_, resource_id_);


--
-- Name: act_id_tenant_member act_uniq_tenant_memb_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_id_tenant_member
    ADD CONSTRAINT act_uniq_tenant_memb_group UNIQUE (tenant_id_, group_id_);


--
-- Name: act_id_tenant_member act_uniq_tenant_memb_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_id_tenant_member
    ADD CONSTRAINT act_uniq_tenant_memb_user UNIQUE (tenant_id_, user_id_);


--
-- Name: act_ru_variable act_uniq_variable; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_variable
    ADD CONSTRAINT act_uniq_variable UNIQUE (var_scope_, name_);


--
-- Name: act_ge_bytearray act_ge_bytearray_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ge_bytearray
    ADD CONSTRAINT act_ge_bytearray_pkey PRIMARY KEY (id_);


--
-- Name: act_ge_property act_ge_property_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ge_property
    ADD CONSTRAINT act_ge_property_pkey PRIMARY KEY (name_);


--
-- Name: act_ge_schema_log act_ge_schema_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ge_schema_log
    ADD CONSTRAINT act_ge_schema_log_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_actinst act_hi_actinst_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_actinst
    ADD CONSTRAINT act_hi_actinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_attachment act_hi_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_attachment
    ADD CONSTRAINT act_hi_attachment_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_batch act_hi_batch_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_batch
    ADD CONSTRAINT act_hi_batch_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_caseactinst act_hi_caseactinst_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_caseactinst
    ADD CONSTRAINT act_hi_caseactinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_caseinst act_hi_caseinst_case_inst_id__key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_caseinst
    ADD CONSTRAINT act_hi_caseinst_case_inst_id__key UNIQUE (case_inst_id_);


--
-- Name: act_hi_caseinst act_hi_caseinst_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_caseinst
    ADD CONSTRAINT act_hi_caseinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_comment act_hi_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_comment
    ADD CONSTRAINT act_hi_comment_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_dec_in act_hi_dec_in_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_dec_in
    ADD CONSTRAINT act_hi_dec_in_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_dec_out act_hi_dec_out_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_dec_out
    ADD CONSTRAINT act_hi_dec_out_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_decinst act_hi_decinst_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_decinst
    ADD CONSTRAINT act_hi_decinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_detail act_hi_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_detail
    ADD CONSTRAINT act_hi_detail_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_ext_task_log act_hi_ext_task_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_ext_task_log
    ADD CONSTRAINT act_hi_ext_task_log_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_identitylink act_hi_identitylink_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_identitylink
    ADD CONSTRAINT act_hi_identitylink_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_incident act_hi_incident_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_incident
    ADD CONSTRAINT act_hi_incident_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_job_log act_hi_job_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_job_log
    ADD CONSTRAINT act_hi_job_log_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_op_log act_hi_op_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_op_log
    ADD CONSTRAINT act_hi_op_log_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_procinst act_hi_procinst_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_procinst
    ADD CONSTRAINT act_hi_procinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_procinst act_hi_procinst_proc_inst_id__key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_procinst
    ADD CONSTRAINT act_hi_procinst_proc_inst_id__key UNIQUE (proc_inst_id_);


--
-- Name: act_hi_taskinst act_hi_taskinst_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_taskinst
    ADD CONSTRAINT act_hi_taskinst_pkey PRIMARY KEY (id_);


--
-- Name: act_hi_varinst act_hi_varinst_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_hi_varinst
    ADD CONSTRAINT act_hi_varinst_pkey PRIMARY KEY (id_);


--
-- Name: act_id_group act_id_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_id_group
    ADD CONSTRAINT act_id_group_pkey PRIMARY KEY (id_);


--
-- Name: act_id_info act_id_info_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_id_info
    ADD CONSTRAINT act_id_info_pkey PRIMARY KEY (id_);


--
-- Name: act_id_tenant_member act_id_tenant_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_id_tenant_member
    ADD CONSTRAINT act_id_tenant_member_pkey PRIMARY KEY (id_);


--
-- Name: act_id_tenant act_id_tenant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_id_tenant
    ADD CONSTRAINT act_id_tenant_pkey PRIMARY KEY (id_);


--
-- Name: act_id_user act_id_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_id_user
    ADD CONSTRAINT act_id_user_pkey PRIMARY KEY (id_);


--
-- Name: act_re_camformdef act_re_camformdef_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_re_camformdef
    ADD CONSTRAINT act_re_camformdef_pkey PRIMARY KEY (id_);


--
-- Name: act_re_case_def act_re_case_def_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_re_case_def
    ADD CONSTRAINT act_re_case_def_pkey PRIMARY KEY (id_);


--
-- Name: act_re_decision_def act_re_decision_def_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_re_decision_def
    ADD CONSTRAINT act_re_decision_def_pkey PRIMARY KEY (id_);


--
-- Name: act_re_decision_req_def act_re_decision_req_def_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_re_decision_req_def
    ADD CONSTRAINT act_re_decision_req_def_pkey PRIMARY KEY (id_);


--
-- Name: act_re_deployment act_re_deployment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_re_deployment
    ADD CONSTRAINT act_re_deployment_pkey PRIMARY KEY (id_);


--
-- Name: act_re_procdef act_re_procdef_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_re_procdef
    ADD CONSTRAINT act_re_procdef_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_authorization act_ru_authorization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_authorization
    ADD CONSTRAINT act_ru_authorization_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_batch act_ru_batch_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_batch
    ADD CONSTRAINT act_ru_batch_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_case_execution act_ru_case_execution_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_case_execution
    ADD CONSTRAINT act_ru_case_execution_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_case_sentry_part act_ru_case_sentry_part_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_case_sentry_part
    ADD CONSTRAINT act_ru_case_sentry_part_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_event_subscr act_ru_event_subscr_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_event_subscr
    ADD CONSTRAINT act_ru_event_subscr_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_execution act_ru_execution_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_execution
    ADD CONSTRAINT act_ru_execution_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_ext_task act_ru_ext_task_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_ext_task
    ADD CONSTRAINT act_ru_ext_task_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_filter act_ru_filter_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_filter
    ADD CONSTRAINT act_ru_filter_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_identitylink act_ru_identitylink_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_identitylink
    ADD CONSTRAINT act_ru_identitylink_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_incident act_ru_incident_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_incident
    ADD CONSTRAINT act_ru_incident_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_job act_ru_job_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_job
    ADD CONSTRAINT act_ru_job_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_jobdef act_ru_jobdef_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_jobdef
    ADD CONSTRAINT act_ru_jobdef_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_meter_log act_ru_meter_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_meter_log
    ADD CONSTRAINT act_ru_meter_log_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_task_meter_log act_ru_task_meter_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_task_meter_log
    ADD CONSTRAINT act_ru_task_meter_log_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_task act_ru_task_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_task
    ADD CONSTRAINT act_ru_task_pkey PRIMARY KEY (id_);


--
-- Name: act_ru_variable act_ru_variable_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_variable
    ADD CONSTRAINT act_ru_variable_pkey PRIMARY KEY (id_);


--
-- Name: dict_materials dict_materials_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dict_materials
    ADD CONSTRAINT dict_materials_pk PRIMARY KEY (id);


--
-- Name: dict_store_operation dict_store_operation_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dict_store_operation
    ADD CONSTRAINT dict_store_operation_pk PRIMARY KEY (id);


--
-- Name: dict_storehouse dict_storehouse_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dict_storehouse
    ADD CONSTRAINT dict_storehouse_pk PRIMARY KEY (id);


--
-- Name: act_hi_bat_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_hi_bat_rm_time ON public.act_hi_batch USING btree (removal_time_);


--
-- Name: act_hi_ext_task_log_proc_def_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_hi_ext_task_log_proc_def_key ON public.act_hi_ext_task_log USING btree (proc_def_key_);


--
-- Name: act_hi_ext_task_log_procdef; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_hi_ext_task_log_procdef ON public.act_hi_ext_task_log USING btree (proc_def_id_);


--
-- Name: act_hi_ext_task_log_procinst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_hi_ext_task_log_procinst ON public.act_hi_ext_task_log USING btree (proc_inst_id_);


--
-- Name: act_hi_ext_task_log_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_hi_ext_task_log_rm_time ON public.act_hi_ext_task_log USING btree (removal_time_);


--
-- Name: act_hi_ext_task_log_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_hi_ext_task_log_root_pi ON public.act_hi_ext_task_log USING btree (root_proc_inst_id_);


--
-- Name: act_hi_ext_task_log_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_hi_ext_task_log_tenant_id ON public.act_hi_ext_task_log USING btree (tenant_id_);


--
-- Name: act_idx_athrz_procedef; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_athrz_procedef ON public.act_ru_identitylink USING btree (proc_def_id_);


--
-- Name: act_idx_auth_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_auth_group_id ON public.act_ru_authorization USING btree (group_id_);


--
-- Name: act_idx_auth_resource_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_auth_resource_id ON public.act_ru_authorization USING btree (resource_id_);


--
-- Name: act_idx_auth_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_auth_rm_time ON public.act_ru_authorization USING btree (removal_time_);


--
-- Name: act_idx_auth_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_auth_root_pi ON public.act_ru_authorization USING btree (root_proc_inst_id_);


--
-- Name: act_idx_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_batch_id ON public.act_ru_variable USING btree (batch_id_);


--
-- Name: act_idx_batch_job_def; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_batch_job_def ON public.act_ru_batch USING btree (batch_job_def_id_);


--
-- Name: act_idx_batch_monitor_job_def; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_batch_monitor_job_def ON public.act_ru_batch USING btree (monitor_job_def_id_);


--
-- Name: act_idx_batch_seed_job_def; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_batch_seed_job_def ON public.act_ru_batch USING btree (seed_job_def_id_);


--
-- Name: act_idx_bytear_depl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_bytear_depl ON public.act_ge_bytearray USING btree (deployment_id_);


--
-- Name: act_idx_bytearray_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_bytearray_name ON public.act_ge_bytearray USING btree (name_);


--
-- Name: act_idx_bytearray_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_bytearray_rm_time ON public.act_ge_bytearray USING btree (removal_time_);


--
-- Name: act_idx_bytearray_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_bytearray_root_pi ON public.act_ge_bytearray USING btree (root_proc_inst_id_);


--
-- Name: act_idx_case_def_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_case_def_tenant_id ON public.act_re_case_def USING btree (tenant_id_);


--
-- Name: act_idx_case_exe_case_def; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_case_exe_case_def ON public.act_ru_case_execution USING btree (case_def_id_);


--
-- Name: act_idx_case_exe_case_inst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_case_exe_case_inst ON public.act_ru_case_execution USING btree (case_inst_id_);


--
-- Name: act_idx_case_exe_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_case_exe_parent ON public.act_ru_case_execution USING btree (parent_id_);


--
-- Name: act_idx_case_exec_buskey; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_case_exec_buskey ON public.act_ru_case_execution USING btree (business_key_);


--
-- Name: act_idx_case_exec_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_case_exec_tenant_id ON public.act_ru_case_execution USING btree (tenant_id_);


--
-- Name: act_idx_case_sentry_case_exec; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_case_sentry_case_exec ON public.act_ru_case_sentry_part USING btree (case_exec_id_);


--
-- Name: act_idx_case_sentry_case_inst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_case_sentry_case_inst ON public.act_ru_case_sentry_part USING btree (case_inst_id_);


--
-- Name: act_idx_dec_def_req_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_dec_def_req_id ON public.act_re_decision_def USING btree (dec_req_id_);


--
-- Name: act_idx_dec_def_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_dec_def_tenant_id ON public.act_re_decision_def USING btree (tenant_id_);


--
-- Name: act_idx_dec_req_def_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_dec_req_def_tenant_id ON public.act_re_decision_req_def USING btree (tenant_id_);


--
-- Name: act_idx_deployment_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_deployment_name ON public.act_re_deployment USING btree (name_);


--
-- Name: act_idx_deployment_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_deployment_tenant_id ON public.act_re_deployment USING btree (tenant_id_);


--
-- Name: act_idx_event_subscr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_event_subscr ON public.act_ru_event_subscr USING btree (execution_id_);


--
-- Name: act_idx_event_subscr_config_; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_event_subscr_config_ ON public.act_ru_event_subscr USING btree (configuration_);


--
-- Name: act_idx_event_subscr_evt_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_event_subscr_evt_name ON public.act_ru_event_subscr USING btree (event_name_);


--
-- Name: act_idx_event_subscr_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_event_subscr_tenant_id ON public.act_ru_event_subscr USING btree (tenant_id_);


--
-- Name: act_idx_exe_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_exe_parent ON public.act_ru_execution USING btree (parent_id_);


--
-- Name: act_idx_exe_procdef; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_exe_procdef ON public.act_ru_execution USING btree (proc_def_id_);


--
-- Name: act_idx_exe_procinst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_exe_procinst ON public.act_ru_execution USING btree (proc_inst_id_);


--
-- Name: act_idx_exe_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_exe_root_pi ON public.act_ru_execution USING btree (root_proc_inst_id_);


--
-- Name: act_idx_exe_super; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_exe_super ON public.act_ru_execution USING btree (super_exec_);


--
-- Name: act_idx_exec_buskey; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_exec_buskey ON public.act_ru_execution USING btree (business_key_);


--
-- Name: act_idx_exec_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_exec_tenant_id ON public.act_ru_execution USING btree (tenant_id_);


--
-- Name: act_idx_ext_task_err_details; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_ext_task_err_details ON public.act_ru_ext_task USING btree (error_details_id_);


--
-- Name: act_idx_ext_task_exec; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_ext_task_exec ON public.act_ru_ext_task USING btree (execution_id_);


--
-- Name: act_idx_ext_task_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_ext_task_priority ON public.act_ru_ext_task USING btree (priority_);


--
-- Name: act_idx_ext_task_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_ext_task_tenant_id ON public.act_ru_ext_task USING btree (tenant_id_);


--
-- Name: act_idx_ext_task_topic; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_ext_task_topic ON public.act_ru_ext_task USING btree (topic_name_);


--
-- Name: act_idx_hi_act_inst_end; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_end ON public.act_hi_actinst USING btree (end_time_);


--
-- Name: act_idx_hi_act_inst_proc_def_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_proc_def_key ON public.act_hi_actinst USING btree (proc_def_key_);


--
-- Name: act_idx_hi_act_inst_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_rm_time ON public.act_hi_actinst USING btree (removal_time_);


--
-- Name: act_idx_hi_act_inst_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_act_inst_tenant_id ON public.act_hi_actinst USING btree (tenant_id_);


--
-- Name: act_idx_hi_actinst_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_actinst_root_pi ON public.act_hi_actinst USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_attachment_content; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_attachment_content ON public.act_hi_attachment USING btree (content_id_);


--
-- Name: act_idx_hi_attachment_procinst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_attachment_procinst ON public.act_hi_attachment USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_attachment_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_attachment_rm_time ON public.act_hi_attachment USING btree (removal_time_);


--
-- Name: act_idx_hi_attachment_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_attachment_root_pi ON public.act_hi_attachment USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_attachment_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_attachment_task ON public.act_hi_attachment USING btree (task_id_);


--
-- Name: act_idx_hi_cas_a_i_create; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_cas_a_i_create ON public.act_hi_caseactinst USING btree (create_time_);


--
-- Name: act_idx_hi_cas_a_i_end; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_cas_a_i_end ON public.act_hi_caseactinst USING btree (end_time_);


--
-- Name: act_idx_hi_cas_a_i_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_cas_a_i_tenant_id ON public.act_hi_caseactinst USING btree (tenant_id_);


--
-- Name: act_idx_hi_cas_i_buskey; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_cas_i_buskey ON public.act_hi_caseinst USING btree (business_key_);


--
-- Name: act_idx_hi_cas_i_close; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_cas_i_close ON public.act_hi_caseinst USING btree (close_time_);


--
-- Name: act_idx_hi_cas_i_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_cas_i_tenant_id ON public.act_hi_caseinst USING btree (tenant_id_);


--
-- Name: act_idx_hi_casevar_case_inst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_casevar_case_inst ON public.act_hi_varinst USING btree (case_inst_id_);


--
-- Name: act_idx_hi_comment_procinst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_comment_procinst ON public.act_hi_comment USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_comment_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_comment_rm_time ON public.act_hi_comment USING btree (removal_time_);


--
-- Name: act_idx_hi_comment_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_comment_root_pi ON public.act_hi_comment USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_comment_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_comment_task ON public.act_hi_comment USING btree (task_id_);


--
-- Name: act_idx_hi_dec_in_inst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_in_inst ON public.act_hi_dec_in USING btree (dec_inst_id_);


--
-- Name: act_idx_hi_dec_in_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_in_rm_time ON public.act_hi_dec_in USING btree (removal_time_);


--
-- Name: act_idx_hi_dec_in_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_in_root_pi ON public.act_hi_dec_in USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_dec_inst_act; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_act ON public.act_hi_decinst USING btree (act_id_);


--
-- Name: act_idx_hi_dec_inst_act_inst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_act_inst ON public.act_hi_decinst USING btree (act_inst_id_);


--
-- Name: act_idx_hi_dec_inst_ci; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_ci ON public.act_hi_decinst USING btree (case_inst_id_);


--
-- Name: act_idx_hi_dec_inst_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_id ON public.act_hi_decinst USING btree (dec_def_id_);


--
-- Name: act_idx_hi_dec_inst_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_key ON public.act_hi_decinst USING btree (dec_def_key_);


--
-- Name: act_idx_hi_dec_inst_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_pi ON public.act_hi_decinst USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_dec_inst_req_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_req_id ON public.act_hi_decinst USING btree (dec_req_id_);


--
-- Name: act_idx_hi_dec_inst_req_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_req_key ON public.act_hi_decinst USING btree (dec_req_key_);


--
-- Name: act_idx_hi_dec_inst_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_rm_time ON public.act_hi_decinst USING btree (removal_time_);


--
-- Name: act_idx_hi_dec_inst_root_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_root_id ON public.act_hi_decinst USING btree (root_dec_inst_id_);


--
-- Name: act_idx_hi_dec_inst_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_root_pi ON public.act_hi_decinst USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_dec_inst_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_tenant_id ON public.act_hi_decinst USING btree (tenant_id_);


--
-- Name: act_idx_hi_dec_inst_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_inst_time ON public.act_hi_decinst USING btree (eval_time_);


--
-- Name: act_idx_hi_dec_out_inst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_out_inst ON public.act_hi_dec_out USING btree (dec_inst_id_);


--
-- Name: act_idx_hi_dec_out_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_out_rm_time ON public.act_hi_dec_out USING btree (removal_time_);


--
-- Name: act_idx_hi_dec_out_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_dec_out_root_pi ON public.act_hi_dec_out USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_detail_act_inst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_detail_act_inst ON public.act_hi_detail USING btree (act_inst_id_);


--
-- Name: act_idx_hi_detail_bytear; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_detail_bytear ON public.act_hi_detail USING btree (bytearray_id_);


--
-- Name: act_idx_hi_detail_case_exec; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_detail_case_exec ON public.act_hi_detail USING btree (case_execution_id_);


--
-- Name: act_idx_hi_detail_case_inst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_detail_case_inst ON public.act_hi_detail USING btree (case_inst_id_);


--
-- Name: act_idx_hi_detail_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_detail_name ON public.act_hi_detail USING btree (name_);


--
-- Name: act_idx_hi_detail_proc_def_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_detail_proc_def_key ON public.act_hi_detail USING btree (proc_def_key_);


--
-- Name: act_idx_hi_detail_proc_inst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_detail_proc_inst ON public.act_hi_detail USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_detail_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_detail_rm_time ON public.act_hi_detail USING btree (removal_time_);


--
-- Name: act_idx_hi_detail_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_detail_root_pi ON public.act_hi_detail USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_detail_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_detail_task_id ON public.act_hi_detail USING btree (task_id_);


--
-- Name: act_idx_hi_detail_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_detail_tenant_id ON public.act_hi_detail USING btree (tenant_id_);


--
-- Name: act_idx_hi_detail_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_detail_time ON public.act_hi_detail USING btree (time_);


--
-- Name: act_idx_hi_detail_var_inst_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_detail_var_inst_id ON public.act_hi_detail USING btree (var_inst_id_);


--
-- Name: act_idx_hi_exttasklog_errordet; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_exttasklog_errordet ON public.act_hi_ext_task_log USING btree (error_details_id_);


--
-- Name: act_idx_hi_ident_link_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_ident_link_rm_time ON public.act_hi_identitylink USING btree (removal_time_);


--
-- Name: act_idx_hi_ident_link_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_ident_link_task ON public.act_hi_identitylink USING btree (task_id_);


--
-- Name: act_idx_hi_ident_lnk_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_ident_lnk_group ON public.act_hi_identitylink USING btree (group_id_);


--
-- Name: act_idx_hi_ident_lnk_proc_def_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_ident_lnk_proc_def_key ON public.act_hi_identitylink USING btree (proc_def_key_);


--
-- Name: act_idx_hi_ident_lnk_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_ident_lnk_root_pi ON public.act_hi_identitylink USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_ident_lnk_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_ident_lnk_tenant_id ON public.act_hi_identitylink USING btree (tenant_id_);


--
-- Name: act_idx_hi_ident_lnk_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_ident_lnk_timestamp ON public.act_hi_identitylink USING btree (timestamp_);


--
-- Name: act_idx_hi_ident_lnk_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_ident_lnk_user ON public.act_hi_identitylink USING btree (user_id_);


--
-- Name: act_idx_hi_incident_create_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_incident_create_time ON public.act_hi_incident USING btree (create_time_);


--
-- Name: act_idx_hi_incident_end_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_incident_end_time ON public.act_hi_incident USING btree (end_time_);


--
-- Name: act_idx_hi_incident_proc_def_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_incident_proc_def_key ON public.act_hi_incident USING btree (proc_def_key_);


--
-- Name: act_idx_hi_incident_procinst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_incident_procinst ON public.act_hi_incident USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_incident_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_incident_rm_time ON public.act_hi_incident USING btree (removal_time_);


--
-- Name: act_idx_hi_incident_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_incident_root_pi ON public.act_hi_incident USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_incident_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_incident_tenant_id ON public.act_hi_incident USING btree (tenant_id_);


--
-- Name: act_idx_hi_job_log_ex_stack; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_job_log_ex_stack ON public.act_hi_job_log USING btree (job_exception_stack_id_);


--
-- Name: act_idx_hi_job_log_job_conf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_job_log_job_conf ON public.act_hi_job_log USING btree (job_def_configuration_);


--
-- Name: act_idx_hi_job_log_job_def_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_job_log_job_def_id ON public.act_hi_job_log USING btree (job_def_id_);


--
-- Name: act_idx_hi_job_log_proc_def_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_job_log_proc_def_key ON public.act_hi_job_log USING btree (process_def_key_);


--
-- Name: act_idx_hi_job_log_procdef; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_job_log_procdef ON public.act_hi_job_log USING btree (process_def_id_);


--
-- Name: act_idx_hi_job_log_procinst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_job_log_procinst ON public.act_hi_job_log USING btree (process_instance_id_);


--
-- Name: act_idx_hi_job_log_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_job_log_rm_time ON public.act_hi_job_log USING btree (removal_time_);


--
-- Name: act_idx_hi_job_log_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_job_log_root_pi ON public.act_hi_job_log USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_job_log_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_job_log_tenant_id ON public.act_hi_job_log USING btree (tenant_id_);


--
-- Name: act_idx_hi_op_log_entity_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_op_log_entity_type ON public.act_hi_op_log USING btree (entity_type_);


--
-- Name: act_idx_hi_op_log_op_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_op_log_op_type ON public.act_hi_op_log USING btree (operation_type_);


--
-- Name: act_idx_hi_op_log_procdef; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_op_log_procdef ON public.act_hi_op_log USING btree (proc_def_id_);


--
-- Name: act_idx_hi_op_log_procinst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_op_log_procinst ON public.act_hi_op_log USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_op_log_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_op_log_rm_time ON public.act_hi_op_log USING btree (removal_time_);


--
-- Name: act_idx_hi_op_log_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_op_log_root_pi ON public.act_hi_op_log USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_op_log_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_op_log_task ON public.act_hi_op_log USING btree (task_id_);


--
-- Name: act_idx_hi_op_log_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_op_log_timestamp ON public.act_hi_op_log USING btree (timestamp_);


--
-- Name: act_idx_hi_op_log_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_op_log_user_id ON public.act_hi_op_log USING btree (user_id_);


--
-- Name: act_idx_hi_pro_i_buskey; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_pro_i_buskey ON public.act_hi_procinst USING btree (business_key_);


--
-- Name: act_idx_hi_pro_inst_end; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_pro_inst_end ON public.act_hi_procinst USING btree (end_time_);


--
-- Name: act_idx_hi_pro_inst_proc_def_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_pro_inst_proc_def_key ON public.act_hi_procinst USING btree (proc_def_key_);


--
-- Name: act_idx_hi_pro_inst_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_pro_inst_rm_time ON public.act_hi_procinst USING btree (removal_time_);


--
-- Name: act_idx_hi_pro_inst_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_pro_inst_root_pi ON public.act_hi_procinst USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_pro_inst_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_pro_inst_tenant_id ON public.act_hi_procinst USING btree (tenant_id_);


--
-- Name: act_idx_hi_procvar_proc_inst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_procvar_proc_inst ON public.act_hi_varinst USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_task_inst_end; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_task_inst_end ON public.act_hi_taskinst USING btree (end_time_);


--
-- Name: act_idx_hi_task_inst_proc_def_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_task_inst_proc_def_key ON public.act_hi_taskinst USING btree (proc_def_key_);


--
-- Name: act_idx_hi_task_inst_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_task_inst_rm_time ON public.act_hi_taskinst USING btree (removal_time_);


--
-- Name: act_idx_hi_task_inst_start; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_task_inst_start ON public.act_hi_taskinst USING btree (start_time_);


--
-- Name: act_idx_hi_task_inst_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_task_inst_tenant_id ON public.act_hi_taskinst USING btree (tenant_id_);


--
-- Name: act_idx_hi_taskinst_procinst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_taskinst_procinst ON public.act_hi_taskinst USING btree (proc_inst_id_);


--
-- Name: act_idx_hi_taskinst_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_taskinst_root_pi ON public.act_hi_taskinst USING btree (root_proc_inst_id_);


--
-- Name: act_idx_hi_var_inst_proc_def_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_var_inst_proc_def_key ON public.act_hi_varinst USING btree (proc_def_key_);


--
-- Name: act_idx_hi_var_inst_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_var_inst_tenant_id ON public.act_hi_varinst USING btree (tenant_id_);


--
-- Name: act_idx_hi_varinst_act_inst_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_varinst_act_inst_id ON public.act_hi_varinst USING btree (act_inst_id_);


--
-- Name: act_idx_hi_varinst_bytear; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_varinst_bytear ON public.act_hi_varinst USING btree (bytearray_id_);


--
-- Name: act_idx_hi_varinst_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_varinst_name ON public.act_hi_varinst USING btree (name_);


--
-- Name: act_idx_hi_varinst_rm_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_varinst_rm_time ON public.act_hi_varinst USING btree (removal_time_);


--
-- Name: act_idx_hi_varinst_root_pi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_hi_varinst_root_pi ON public.act_hi_varinst USING btree (root_proc_inst_id_);


--
-- Name: act_idx_ident_lnk_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_ident_lnk_group ON public.act_ru_identitylink USING btree (group_id_);


--
-- Name: act_idx_ident_lnk_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_ident_lnk_user ON public.act_ru_identitylink USING btree (user_id_);


--
-- Name: act_idx_inc_causeincid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_inc_causeincid ON public.act_ru_incident USING btree (cause_incident_id_);


--
-- Name: act_idx_inc_configuration; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_inc_configuration ON public.act_ru_incident USING btree (configuration_);


--
-- Name: act_idx_inc_exid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_inc_exid ON public.act_ru_incident USING btree (execution_id_);


--
-- Name: act_idx_inc_job_def; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_inc_job_def ON public.act_ru_incident USING btree (job_def_id_);


--
-- Name: act_idx_inc_procdefid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_inc_procdefid ON public.act_ru_incident USING btree (proc_def_id_);


--
-- Name: act_idx_inc_procinstid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_inc_procinstid ON public.act_ru_incident USING btree (proc_inst_id_);


--
-- Name: act_idx_inc_rootcauseincid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_inc_rootcauseincid ON public.act_ru_incident USING btree (root_cause_incident_id_);


--
-- Name: act_idx_inc_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_inc_tenant_id ON public.act_ru_incident USING btree (tenant_id_);


--
-- Name: act_idx_job_exception; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_job_exception ON public.act_ru_job USING btree (exception_stack_id_);


--
-- Name: act_idx_job_execution_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_job_execution_id ON public.act_ru_job USING btree (execution_id_);


--
-- Name: act_idx_job_handler_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_job_handler_type ON public.act_ru_job USING btree (handler_type_);


--
-- Name: act_idx_job_job_def_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_job_job_def_id ON public.act_ru_job USING btree (job_def_id_);


--
-- Name: act_idx_job_procinst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_job_procinst ON public.act_ru_job USING btree (process_instance_id_);


--
-- Name: act_idx_job_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_job_tenant_id ON public.act_ru_job USING btree (tenant_id_);


--
-- Name: act_idx_jobdef_proc_def_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_jobdef_proc_def_id ON public.act_ru_jobdef USING btree (proc_def_id_);


--
-- Name: act_idx_jobdef_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_jobdef_tenant_id ON public.act_ru_jobdef USING btree (tenant_id_);


--
-- Name: act_idx_memb_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_memb_group ON public.act_id_membership USING btree (group_id_);


--
-- Name: act_idx_memb_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_memb_user ON public.act_id_membership USING btree (user_id_);


--
-- Name: act_idx_meter_log_ms; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_meter_log_ms ON public.act_ru_meter_log USING btree (milliseconds_);


--
-- Name: act_idx_meter_log_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_meter_log_time ON public.act_ru_meter_log USING btree (timestamp_);


--
-- Name: act_idx_procdef_deployment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_procdef_deployment_id ON public.act_re_procdef USING btree (deployment_id_);


--
-- Name: act_idx_procdef_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_procdef_tenant_id ON public.act_re_procdef USING btree (tenant_id_);


--
-- Name: act_idx_procdef_ver_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_procdef_ver_tag ON public.act_re_procdef USING btree (version_tag_);


--
-- Name: act_idx_task_assignee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_task_assignee ON public.act_ru_task USING btree (assignee_);


--
-- Name: act_idx_task_case_def_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_task_case_def_id ON public.act_ru_task USING btree (case_def_id_);


--
-- Name: act_idx_task_case_exec; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_task_case_exec ON public.act_ru_task USING btree (case_execution_id_);


--
-- Name: act_idx_task_create; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_task_create ON public.act_ru_task USING btree (create_time_);


--
-- Name: act_idx_task_exec; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_task_exec ON public.act_ru_task USING btree (execution_id_);


--
-- Name: act_idx_task_last_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_task_last_updated ON public.act_ru_task USING btree (last_updated_);


--
-- Name: act_idx_task_meter_log_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_task_meter_log_time ON public.act_ru_task_meter_log USING btree (timestamp_);


--
-- Name: act_idx_task_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_task_owner ON public.act_ru_task USING btree (owner_);


--
-- Name: act_idx_task_procdef; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_task_procdef ON public.act_ru_task USING btree (proc_def_id_);


--
-- Name: act_idx_task_procinst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_task_procinst ON public.act_ru_task USING btree (proc_inst_id_);


--
-- Name: act_idx_task_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_task_tenant_id ON public.act_ru_task USING btree (tenant_id_);


--
-- Name: act_idx_tenant_memb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_tenant_memb ON public.act_id_tenant_member USING btree (tenant_id_);


--
-- Name: act_idx_tenant_memb_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_tenant_memb_group ON public.act_id_tenant_member USING btree (group_id_);


--
-- Name: act_idx_tenant_memb_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_tenant_memb_user ON public.act_id_tenant_member USING btree (user_id_);


--
-- Name: act_idx_tskass_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_tskass_task ON public.act_ru_identitylink USING btree (task_id_);


--
-- Name: act_idx_var_bytearray; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_var_bytearray ON public.act_ru_variable USING btree (bytearray_id_);


--
-- Name: act_idx_var_case_exe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_var_case_exe ON public.act_ru_variable USING btree (case_execution_id_);


--
-- Name: act_idx_var_case_inst_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_var_case_inst_id ON public.act_ru_variable USING btree (case_inst_id_);


--
-- Name: act_idx_var_exe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_var_exe ON public.act_ru_variable USING btree (execution_id_);


--
-- Name: act_idx_var_procinst; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_var_procinst ON public.act_ru_variable USING btree (proc_inst_id_);


--
-- Name: act_idx_variable_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_variable_task_id ON public.act_ru_variable USING btree (task_id_);


--
-- Name: act_idx_variable_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX act_idx_variable_tenant_id ON public.act_ru_variable USING btree (tenant_id_);


--
-- Name: dict_materials_name_udx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX dict_materials_name_udx ON public.dict_materials USING btree (name);


--
-- Name: dict_store_operation_material_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dict_store_operation_material_id_idx ON public.dict_store_operation USING btree (material_id);


--
-- Name: dict_storehouse_material_id_udx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX dict_storehouse_material_id_udx ON public.dict_storehouse USING btree (material_id);


--
-- Name: act_ru_identitylink act_fk_athrz_procedef; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_identitylink
    ADD CONSTRAINT act_fk_athrz_procedef FOREIGN KEY (proc_def_id_) REFERENCES public.act_re_procdef(id_);


--
-- Name: act_ru_batch act_fk_batch_job_def; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_batch
    ADD CONSTRAINT act_fk_batch_job_def FOREIGN KEY (batch_job_def_id_) REFERENCES public.act_ru_jobdef(id_);


--
-- Name: act_ru_batch act_fk_batch_monitor_job_def; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_batch
    ADD CONSTRAINT act_fk_batch_monitor_job_def FOREIGN KEY (monitor_job_def_id_) REFERENCES public.act_ru_jobdef(id_);


--
-- Name: act_ru_batch act_fk_batch_seed_job_def; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_batch
    ADD CONSTRAINT act_fk_batch_seed_job_def FOREIGN KEY (seed_job_def_id_) REFERENCES public.act_ru_jobdef(id_);


--
-- Name: act_ge_bytearray act_fk_bytearr_depl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ge_bytearray
    ADD CONSTRAINT act_fk_bytearr_depl FOREIGN KEY (deployment_id_) REFERENCES public.act_re_deployment(id_);


--
-- Name: act_ru_case_execution act_fk_case_exe_case_def; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_case_execution
    ADD CONSTRAINT act_fk_case_exe_case_def FOREIGN KEY (case_def_id_) REFERENCES public.act_re_case_def(id_);


--
-- Name: act_ru_case_execution act_fk_case_exe_case_inst; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_case_execution
    ADD CONSTRAINT act_fk_case_exe_case_inst FOREIGN KEY (case_inst_id_) REFERENCES public.act_ru_case_execution(id_);


--
-- Name: act_ru_case_execution act_fk_case_exe_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_case_execution
    ADD CONSTRAINT act_fk_case_exe_parent FOREIGN KEY (parent_id_) REFERENCES public.act_ru_case_execution(id_);


--
-- Name: act_ru_case_sentry_part act_fk_case_sentry_case_exec; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_case_sentry_part
    ADD CONSTRAINT act_fk_case_sentry_case_exec FOREIGN KEY (case_exec_id_) REFERENCES public.act_ru_case_execution(id_);


--
-- Name: act_ru_case_sentry_part act_fk_case_sentry_case_inst; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_case_sentry_part
    ADD CONSTRAINT act_fk_case_sentry_case_inst FOREIGN KEY (case_inst_id_) REFERENCES public.act_ru_case_execution(id_);


--
-- Name: act_re_decision_def act_fk_dec_req; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_re_decision_def
    ADD CONSTRAINT act_fk_dec_req FOREIGN KEY (dec_req_id_) REFERENCES public.act_re_decision_req_def(id_);


--
-- Name: act_ru_event_subscr act_fk_event_exec; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_event_subscr
    ADD CONSTRAINT act_fk_event_exec FOREIGN KEY (execution_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_execution act_fk_exe_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_execution
    ADD CONSTRAINT act_fk_exe_parent FOREIGN KEY (parent_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_execution act_fk_exe_procdef; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_execution
    ADD CONSTRAINT act_fk_exe_procdef FOREIGN KEY (proc_def_id_) REFERENCES public.act_re_procdef(id_);


--
-- Name: act_ru_execution act_fk_exe_procinst; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_execution
    ADD CONSTRAINT act_fk_exe_procinst FOREIGN KEY (proc_inst_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_execution act_fk_exe_super; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_execution
    ADD CONSTRAINT act_fk_exe_super FOREIGN KEY (super_exec_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_ext_task act_fk_ext_task_error_details; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_ext_task
    ADD CONSTRAINT act_fk_ext_task_error_details FOREIGN KEY (error_details_id_) REFERENCES public.act_ge_bytearray(id_);


--
-- Name: act_ru_ext_task act_fk_ext_task_exe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_ext_task
    ADD CONSTRAINT act_fk_ext_task_exe FOREIGN KEY (execution_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_incident act_fk_inc_cause; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_incident
    ADD CONSTRAINT act_fk_inc_cause FOREIGN KEY (cause_incident_id_) REFERENCES public.act_ru_incident(id_);


--
-- Name: act_ru_incident act_fk_inc_exe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_incident
    ADD CONSTRAINT act_fk_inc_exe FOREIGN KEY (execution_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_incident act_fk_inc_job_def; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_incident
    ADD CONSTRAINT act_fk_inc_job_def FOREIGN KEY (job_def_id_) REFERENCES public.act_ru_jobdef(id_);


--
-- Name: act_ru_incident act_fk_inc_procdef; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_incident
    ADD CONSTRAINT act_fk_inc_procdef FOREIGN KEY (proc_def_id_) REFERENCES public.act_re_procdef(id_);


--
-- Name: act_ru_incident act_fk_inc_procinst; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_incident
    ADD CONSTRAINT act_fk_inc_procinst FOREIGN KEY (proc_inst_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_incident act_fk_inc_rcause; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_incident
    ADD CONSTRAINT act_fk_inc_rcause FOREIGN KEY (root_cause_incident_id_) REFERENCES public.act_ru_incident(id_);


--
-- Name: act_ru_job act_fk_job_exception; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_job
    ADD CONSTRAINT act_fk_job_exception FOREIGN KEY (exception_stack_id_) REFERENCES public.act_ge_bytearray(id_);


--
-- Name: act_id_membership act_fk_memb_group; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_id_membership
    ADD CONSTRAINT act_fk_memb_group FOREIGN KEY (group_id_) REFERENCES public.act_id_group(id_);


--
-- Name: act_id_membership act_fk_memb_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_id_membership
    ADD CONSTRAINT act_fk_memb_user FOREIGN KEY (user_id_) REFERENCES public.act_id_user(id_);


--
-- Name: act_ru_task act_fk_task_case_def; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_task
    ADD CONSTRAINT act_fk_task_case_def FOREIGN KEY (case_def_id_) REFERENCES public.act_re_case_def(id_);


--
-- Name: act_ru_task act_fk_task_case_exe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_task
    ADD CONSTRAINT act_fk_task_case_exe FOREIGN KEY (case_execution_id_) REFERENCES public.act_ru_case_execution(id_);


--
-- Name: act_ru_task act_fk_task_exe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_task
    ADD CONSTRAINT act_fk_task_exe FOREIGN KEY (execution_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_task act_fk_task_procdef; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_task
    ADD CONSTRAINT act_fk_task_procdef FOREIGN KEY (proc_def_id_) REFERENCES public.act_re_procdef(id_);


--
-- Name: act_ru_task act_fk_task_procinst; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_task
    ADD CONSTRAINT act_fk_task_procinst FOREIGN KEY (proc_inst_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_id_tenant_member act_fk_tenant_memb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_id_tenant_member
    ADD CONSTRAINT act_fk_tenant_memb FOREIGN KEY (tenant_id_) REFERENCES public.act_id_tenant(id_);


--
-- Name: act_id_tenant_member act_fk_tenant_memb_group; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_id_tenant_member
    ADD CONSTRAINT act_fk_tenant_memb_group FOREIGN KEY (group_id_) REFERENCES public.act_id_group(id_);


--
-- Name: act_id_tenant_member act_fk_tenant_memb_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_id_tenant_member
    ADD CONSTRAINT act_fk_tenant_memb_user FOREIGN KEY (user_id_) REFERENCES public.act_id_user(id_);


--
-- Name: act_ru_identitylink act_fk_tskass_task; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_identitylink
    ADD CONSTRAINT act_fk_tskass_task FOREIGN KEY (task_id_) REFERENCES public.act_ru_task(id_);


--
-- Name: act_ru_variable act_fk_var_batch; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_variable
    ADD CONSTRAINT act_fk_var_batch FOREIGN KEY (batch_id_) REFERENCES public.act_ru_batch(id_);


--
-- Name: act_ru_variable act_fk_var_bytearray; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_variable
    ADD CONSTRAINT act_fk_var_bytearray FOREIGN KEY (bytearray_id_) REFERENCES public.act_ge_bytearray(id_);


--
-- Name: act_ru_variable act_fk_var_case_exe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_variable
    ADD CONSTRAINT act_fk_var_case_exe FOREIGN KEY (case_execution_id_) REFERENCES public.act_ru_case_execution(id_);


--
-- Name: act_ru_variable act_fk_var_case_inst; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_variable
    ADD CONSTRAINT act_fk_var_case_inst FOREIGN KEY (case_inst_id_) REFERENCES public.act_ru_case_execution(id_);


--
-- Name: act_ru_variable act_fk_var_exe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_variable
    ADD CONSTRAINT act_fk_var_exe FOREIGN KEY (execution_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: act_ru_variable act_fk_var_procinst; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_ru_variable
    ADD CONSTRAINT act_fk_var_procinst FOREIGN KEY (proc_inst_id_) REFERENCES public.act_ru_execution(id_);


--
-- Name: dict_store_operation dict_store_operation_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dict_store_operation
    ADD CONSTRAINT dict_store_operation_fk FOREIGN KEY (material_id) REFERENCES public.dict_materials(id);


--
-- Name: dict_storehouse dict_storehouse_material_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dict_storehouse
    ADD CONSTRAINT dict_storehouse_material_id_fk FOREIGN KEY (material_id) REFERENCES public.dict_materials(id);


--
-- PostgreSQL database dump complete
--

